#include "stm32f10x.h"
#include <stdio.h>
#include "ax_sys.h"
#include "ax_delay.h"
#include "ax_led.h"
#include "ax_uart1.h"
#include "ax_ps2.h"

JOYSTICK_TypeDef my_joystick;

// ????:???? (0 = ????, 1 = ?????)
uint8_t robot_mode = 0; 

// ==========================================
// 1. ??????????
// ==========================================
void Motor_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);

    // ?? PA1, PA2
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // ?? PB0, PB1
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // ?? PA3, PB3 (???????????PB3)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; 
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; 
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // ?? PB4, PB5
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // ??????????,??????
    GPIO_ResetBits(GPIOA, GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3);
    GPIO_ResetBits(GPIOB, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5);
}

void Motor_Control(int ly, int lx, int rx) {
    int fl = ly + lx + rx; // ??
    int fr = ly - lx - rx; // ??
    int rl = ly - lx + rx; // ??
    int rr = ly + lx - rx; // ??

    // ?? (PA1, PA2)
    if(fl > 20) { GPIO_SetBits(GPIOA, GPIO_Pin_1); GPIO_ResetBits(GPIOA, GPIO_Pin_2); }
    else if(fl < -20) { GPIO_ResetBits(GPIOA, GPIO_Pin_1); GPIO_SetBits(GPIOA, GPIO_Pin_2); }
    else { GPIO_ResetBits(GPIOA, GPIO_Pin_1); GPIO_ResetBits(GPIOA, GPIO_Pin_2); }

    // ?? (PB0, PB1)
    if(fr > 20) { GPIO_SetBits(GPIOB, GPIO_Pin_0); GPIO_ResetBits(GPIOB, GPIO_Pin_1); }
    else if(fr < -20) { GPIO_ResetBits(GPIOB, GPIO_Pin_0); GPIO_SetBits(GPIOB, GPIO_Pin_1); }
    else { GPIO_ResetBits(GPIOB, GPIO_Pin_0); GPIO_ResetBits(GPIOB, GPIO_Pin_1); }

    // ?? (PA3, PB3)
    if(rl > 20) { GPIO_SetBits(GPIOA, GPIO_Pin_3); GPIO_ResetBits(GPIOB, GPIO_Pin_3); }
    else if(rl < -20) { GPIO_ResetBits(GPIOA, GPIO_Pin_3); GPIO_SetBits(GPIOB, GPIO_Pin_3); }
    else { GPIO_ResetBits(GPIOA, GPIO_Pin_3); GPIO_ResetBits(GPIOB, GPIO_Pin_3); }

    // ?? (PB4, PB5)
    if(rr > 20) { GPIO_SetBits(GPIOB, GPIO_Pin_4); GPIO_ResetBits(GPIOB, GPIO_Pin_5); }
    else if(rr < -20) { GPIO_ResetBits(GPIOB, GPIO_Pin_4); GPIO_SetBits(GPIOB, GPIO_Pin_5); }
    else { GPIO_ResetBits(GPIOB, GPIO_Pin_4); GPIO_ResetBits(GPIOB, GPIO_Pin_5); }
}

// ==========================================
// 2. ?????????????
// ==========================================
void Servo_Init(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

    // PB6, PB7, PB8, PB9 ??????
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // 72MHz / 72 = 1MHz, 1MHz / 20000 = 50Hz
    TIM_TimeBaseStructure.TIM_Period = 19999;
    TIM_TimeBaseStructure.TIM_Prescaler = 71;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 1500; // ??90?
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

    TIM_OC1Init(TIM4, &TIM_OCInitStructure); // PB6
    TIM_OC2Init(TIM4, &TIM_OCInitStructure); // PB7
    TIM_OC3Init(TIM4, &TIM_OCInitStructure); // PB8
    TIM_OC4Init(TIM4, &TIM_OCInitStructure); // PB9

    TIM_Cmd(TIM4, ENABLE);
}

void Set_Servo_Angle(uint8_t ch, uint8_t angle) {
    if(angle > 180) angle = 180;
    uint16_t pulse = 500 + (angle * 2000) / 180; 
    switch(ch) {
        case 1: TIM_SetCompare1(TIM4, pulse); break; // ??
        case 2: TIM_SetCompare2(TIM4, pulse); break; // ??
        case 3: TIM_SetCompare3(TIM4, pulse); break; // ??
        case 4: TIM_SetCompare4(TIM4, pulse); break; // ??
    }
}

// ==========================================
// 3. ???
// ==========================================
int main(void)
{	
    // ?? ????:?? JTAG ??,?????(PB4)????(PB3)
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE); 
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE); 

	AX_DELAY_Init();   
	AX_LED_Init();  
	AX_UART1_Init(115200);
	printf("***CRTC 2026 ???????***\r\n");	
	
	AX_PS2_Init();	 
    Motor_Init();    
    Servo_Init(); // ??????PWM
    
    // ????????? 90 ???
    int arm_angle[4] = {90, 90, 90, 90};
    for(int i=1; i<=4; i++) Set_Servo_Angle(i, 90);

    // ???????
    my_joystick.mode = 0; 
    my_joystick.LJoy_UD = 128; my_joystick.LJoy_LR = 128; my_joystick.RJoy_LR = 128;

    // ??????? 1 ?,???????
    Motor_Control(0, 0, 0); 
    AX_Delayms(1000); 

    uint8_t last_btn1 = 0xFF; // ?????????,????

	while (1)
	{
		AX_PS2_ScanKey(&my_joystick);
		
        // ????????(0x73/0x53)??????
        if (my_joystick.mode == 0x73 || my_joystick.mode == 0x53)
        {
            // --- ??????:?? SELECT ? (?? btn1 ? bit0) ---
            if ((my_joystick.btn1 & 0x01) == 0 && (last_btn1 & 0x01) != 0) {
                robot_mode = !robot_mode; // ????
                printf("????: %s\r\n", robot_mode ? "???" : "??");
                // ???????,??????
                Motor_Control(0, 0, 0); 
            }
            last_btn1 = my_joystick.btn1;

            // ????????????
            if (robot_mode == 0) 
            {
                // ========== ?????? ==========
                int ly = 128 - my_joystick.LJoy_UD; 
                int lx = -(128 - my_joystick.LJoy_LR); // ??????
                int rx = my_joystick.RJoy_LR - 128;
                
                if(ly > -50 && ly < 50) ly = 0;
                if(lx > -50 && lx < 50) lx = 0;
                if(rx > -50 && rx < 50) rx = 0;

                Motor_Control(ly, lx, rx);
            }
            else 
            {
                // ========== ??????? ==========
                Motor_Control(0, 0, 0); // ??????
                
                // ????? -> ???? (??1)
                if (my_joystick.LJoy_LR > 160) arm_angle[0] += 2;
                if (my_joystick.LJoy_LR < 96)  arm_angle[0] -= 2;

                // ????? -> ???? (??2)
                if (my_joystick.LJoy_UD > 160) arm_angle[1] += 2;
                if (my_joystick.LJoy_UD < 96)  arm_angle[1] -= 2;

                // ????? -> ???? (??3)
                if (my_joystick.RJoy_LR > 160) arm_angle[2] += 2;
                if (my_joystick.RJoy_LR < 96)  arm_angle[2] -= 2;

                // ????? -> ???? (??4)
                if (my_joystick.RJoy_UD > 160) arm_angle[3] += 2;
                if (my_joystick.RJoy_UD < 96)  arm_angle[3] -= 2;

                // ???????
                for(int i=0; i<4; i++) {
                    if(arm_angle[i] < 0) arm_angle[i] = 0;
                    if(arm_angle[i] > 180) arm_angle[i] = 180;
                    Set_Servo_Angle(i+1, arm_angle[i]);
                }
            }
        }
        else
        {
            // ????????,??????
            Motor_Control(0, 0, 0);
        }

		AX_Delayms(20); // 20ms ????,????????
	}
}